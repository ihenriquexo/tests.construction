var idade
var nome
idade = prompt("Insira a sua idade")
nome = prompt("Insira seu nome")
//Para printar no console
console.log(nome)
console.log(idade)